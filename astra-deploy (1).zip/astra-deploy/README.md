# ASTRA – Astronaut Health & Mission Simulation (Streamlit)

Files: app.py (entry point), astra_ui.py, mars_mission.py, requirements.txt

## Run locally
    pip install -r requirements.txt
    streamlit run app.py

## Deploy
- Streamlit Community Cloud: push this folder to GitHub, then share.streamlit.io -> New app -> main file `app.py`.
- Docker (Render, Fly.io, Railway, Cloud Run, any VPS):
      docker build -t astra .
      docker run -p 8501:8501 -v astra_data:/app astra
  The app honors $PORT. Records are stored in SQLite (astra_records.db) next to app.py.

## Note on persistence
Most hosts have an ephemeral filesystem, so saved logs reset on redeploy/restart.
Mount a persistent volume at the app directory, or move storage to an external database.
