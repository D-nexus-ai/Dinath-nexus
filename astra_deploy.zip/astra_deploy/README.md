# ASTRA – Astronaut Health & Mission Simulation (Streamlit)

## Required files (entry point: app.py)
- app.py
- astra_insights.py
- astra_ui.py        <-- NOT INCLUDED YET, you must add it
- mars_mission.py    <-- NOT INCLUDED YET, you must add it

app.py imports astra_ui and mars_mission, so the app will not start until
both sit in this folder next to app.py.

## Run locally
    python -m venv .venv && source .venv/bin/activate
    pip install -r requirements.txt
    streamlit run app.py

## Deploy on Streamlit Community Cloud (free)
1. Put this folder in a GitHub repo.
2. share.streamlit.io -> New app -> pick the repo, branch, main file: app.py
3. Deploy.

## Notes
- Records are saved to SQLite (astra_records.db) beside app.py. Community Cloud
  and most hosts have ephemeral disks, so data resets on restart/redeploy.
  Use an external database if you need durable storage.
- Demo data only; do not enter real health information.
